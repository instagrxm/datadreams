<?php

namespace InstagramAPI\Realtime\Handler;

class HandlerException extends \DomainException
{
}
