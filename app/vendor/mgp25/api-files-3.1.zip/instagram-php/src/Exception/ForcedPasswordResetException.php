<?php

namespace InstagramAPI\Exception;

class ForcedPasswordResetException extends RequestException
{
}
