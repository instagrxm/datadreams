<?php

namespace InstagramAPI\Exception;

/**
 * Used for all problems with the Settings storage.
 */
class SettingsException extends InternalException
{
}
