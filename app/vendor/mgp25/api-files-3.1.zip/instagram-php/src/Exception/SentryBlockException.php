<?php

namespace InstagramAPI\Exception;

class SentryBlockException extends RequestException
{
}
